//1. Display This Information using print
#include<stdio.h>
#include<conio.h>
int  main(){
            printf("\n My Name is: Parag");
            printf("\n My Date Of Birth is: 7102");
            printf("\n My Age is: 22");
            printf("\n My Address is: Rander");
   return 0;
}