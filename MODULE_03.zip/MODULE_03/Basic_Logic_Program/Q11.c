// 11. Find circumference of square
#include<stdio.h>
#include<conio.h>

int main() {
    float rs, perimeter;

    printf("\n Enter the length: ");
    scanf("%f", &rs);

    perimeter = 4 * rs;

    printf("\n The perimeter of the square is: %f", perimeter);

    return 0;
}
