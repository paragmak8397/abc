// 4. Find area of square
#include <stdio.h>  
int main()  
{  
   int pm=17;  
   int area_square=pm*pm;  
   printf("\n Area of the square=%d",area_square);  
}  