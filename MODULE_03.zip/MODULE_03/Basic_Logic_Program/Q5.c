//5. Find Area of Cube
#include<stdio.h>
#include<conio.h>
int main(){
    int cube;
    printf("\n Enter the Value of Cube:");
    scanf("%d",&cube);
    int area_of_cube = 6*cube*cube;
    printf("\n Area of Cube=%d",area_of_cube);
    
    return 0;

}