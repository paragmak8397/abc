//8. Find circumference of Rectangle
#include<stdio.h>
int main(){ 
    float a , b, c, d ,perimeter;
    a = c = 17;
    b = d = 9;
    perimeter = 2*(a+b);

    printf("\n\n Perimeter of Rectangle is : %f",perimeter);
    
    return 0;
}